import pytest
from pathlib import Path
from PIL import Image
import shutil
from collections import defaultdict
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_validation import check_images, is_image_corrupt, analyze_balance

# 自动创建 mock_dataset 路径及报告文件
REPORT_FILE = Path("mock_dataset/test_check_balance.md")
REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
REPORT_FILE.write_text("# test_check_balance 自动化测试报告\n", encoding="utf-8")

def write_report(title, lines):
    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(REPORT_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n## {title}\n\n")
        for line in lines:
            f.write(f"{line}\n")
        f.write("\n")

def create_good_image(path: Path):
    img = Image.new('RGB', (10, 10), color='green')
    img.save(path, format='JPEG')

def create_bad_image(path: Path):
    with open(path, "wb") as f:
        f.write(b"ThisIsNotAValidImageContent")

@pytest.fixture(scope="function")
def prepare_train_dataset(request):
    test_name = request.node.originalname.replace("test_", "")
    test_dir = Path(f"mock_dataset/train_{test_name}")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)

    yield test_dir

    write_report(
        f"{test_name} 数据集保留",
        [f"- {test_dir.resolve()} 保留以便复查，如需清理请手动执行"]
    )

def format_class_counts(class_counts, corrupt_counts):
    lines = ["训练集类别样本数量", ""]
    for cls in sorted(class_counts.keys()):
        count = class_counts[cls]
        corrupt = corrupt_counts.get(cls, 0)
        if corrupt > 0:
            lines.append(f"- {cls}: {count} 张图片（其中 {corrupt} 张损坏）")
        else:
            lines.append(f"- {cls}: {count} 张图片")
    return lines

def test_analyze_balance_no_corrupt(prepare_train_dataset):
    test_dir = prepare_train_dataset

    class_names = ["10000", "10001"]
    for cls in class_names:
        cls_dir = test_dir / cls
        cls_dir.mkdir(parents=True, exist_ok=True)
        for i in range(5):
            create_good_image(cls_dir / f"{i}.jpg")

    corrupt_files = []

    class_counts, corrupt_counts = analyze_balance(str(test_dir), corrupt_files)

    lines = format_class_counts(class_counts, corrupt_counts)
    write_report("analyze_balance_no_corrupt", lines)

    assert all(v == 5 for v in class_counts.values())
    assert all(v == 0 for v in corrupt_counts.values())

def test_analyze_balance_with_corrupt(prepare_train_dataset):
    test_dir = prepare_train_dataset

    class_names = ["10002", "10003"]
    corrupt_files = []

    for cls in class_names:
        cls_dir = test_dir / cls
        cls_dir.mkdir(parents=True, exist_ok=True)
        for i in range(5):
            img_path = cls_dir / f"{i}.jpg"
            if i == 2:
                create_bad_image(img_path)
                corrupt_files.append(str(img_path))
            else:
                create_good_image(img_path)

    class_counts, corrupt_counts = analyze_balance(str(test_dir), corrupt_files)

    lines = format_class_counts(class_counts, corrupt_counts)
    write_report("analyze_balance_with_corrupt", lines)

    assert all(v == 5 for v in class_counts.values())
    assert all(v == 1 for v in corrupt_counts.values())

def test_analyze_balance_all_corrupt(prepare_train_dataset):
    test_dir = prepare_train_dataset

    class_names = ["10004"]
    corrupt_files = []

    for cls in class_names:
        cls_dir = test_dir / cls
        cls_dir.mkdir(parents=True, exist_ok=True)
        for i in range(3):
            img_path = cls_dir / f"{i}.jpg"
            create_bad_image(img_path)
            corrupt_files.append(str(img_path))

    class_counts, corrupt_counts = analyze_balance(str(test_dir), corrupt_files)

    lines = format_class_counts(class_counts, corrupt_counts)
    write_report("analyze_balance_all_corrupt", lines)

    assert list(class_counts.values())[0] == 3
    assert list(corrupt_counts.values())[0] == 3

def test_analyze_balance_class_no_images(prepare_train_dataset):
    test_dir = prepare_train_dataset

    class_names = ["10005", "10006"]
    for cls in class_names:
        cls_dir = test_dir / cls
        cls_dir.mkdir(parents=True, exist_ok=True)
        # 不创建任何图片

    corrupt_files = []

    class_counts, corrupt_counts = analyze_balance(str(test_dir), corrupt_files)

    lines = format_class_counts(class_counts, corrupt_counts)
    write_report("analyze_balance_class_no_images", lines)

    # 断言应有类别但图片数为0，损坏数为0
    assert all(v == 0 for v in class_counts.values())
    assert all(v == 0 for v in corrupt_counts.values())
