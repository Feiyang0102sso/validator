import os
import sys
import random
import shutil
from pathlib import Path
from PIL import Image
import pytest

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_validation import find_valid_structure_dirs, check_images, analyze_balance

# --- 可视化保留路径：便于查看生成的 mock 数据 ---
MOCK_DATA_ROOT = Path(__file__).parent / "mock_dataset"

# 生成正常图片
def create_valid_image(path):
    img = Image.new('RGB', (random.randint(10, 20), random.randint(10, 20)), color=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
    img.save(path, format='JPEG')

# 生成损坏图片
def create_corrupt_image(path):
    with open(path, 'wb') as f:
        f.write(os.urandom(random.randint(10, 100)))  # 随机长度损坏内容

@pytest.fixture(scope="session")
def mock_dataset():
    """
    创建 mock 数据集：
    - train/10000: N张随机好/坏图片
    - train/10001: 空类别
    - val/10000: 损坏图片
    - validation/: 随机好图片
    - test/: 随机好/坏图片
    - wrong_folder/: 错误结构
    """

    if MOCK_DATA_ROOT.exists():
        shutil.rmtree(MOCK_DATA_ROOT)
    MOCK_DATA_ROOT.mkdir(parents=True)

    # 参数
    num_classes = 2
    images_per_class = 3
    corrupt_prob = 0.3

    # 创建 train/10000, 10001
    train_root = MOCK_DATA_ROOT / "train"
    for cls_id in range(10000, 10000 + num_classes):
        cls_dir = train_root / str(cls_id)
        cls_dir.mkdir(parents=True)
        if cls_id == 10001:
            # 空类别
            continue
        for idx in range(images_per_class):
            img_path = cls_dir / f"img_{idx}.jpg"
            if random.random() < corrupt_prob:
                create_corrupt_image(img_path)
            else:
                create_valid_image(img_path)

    # 创建 val/10000，内含损坏图片
    val_dir = MOCK_DATA_ROOT / "val" / "10000"
    val_dir.mkdir(parents=True)
    create_corrupt_image(val_dir / "corrupt.jpg")

    # 创建 validation/ 含正常图片
    validation_dir = MOCK_DATA_ROOT / "validation"
    validation_dir.mkdir(parents=True)
    create_valid_image(validation_dir / "val_good.jpg")

    # 创建 test/ 含随机好坏图片
    test_dir = MOCK_DATA_ROOT / "test"
    test_dir.mkdir(parents=True)
    for idx in range(2):
        img_path = test_dir / f"test_img_{idx}.jpg"
        if random.random() < corrupt_prob:
            create_corrupt_image(img_path)
        else:
            create_valid_image(img_path)

    # 创建错误结构
    wrong_dir = MOCK_DATA_ROOT / "wrong_folder"
    wrong_dir.mkdir()
    (wrong_dir / "file.txt").write_text("hello")

    return MOCK_DATA_ROOT

# ----------------- 测试用例 -------------------

def test_find_valid_structure_dirs(mock_dataset):
    found_dirs = find_valid_structure_dirs(str(mock_dataset))
    found_keywords = [kw for kw, _ in found_dirs]
    assert "train" in found_keywords
    assert "val" in found_keywords
    assert "validation" in found_keywords
    assert "test" in found_keywords
    assert "wrong" not in found_keywords
    assert "111" not in found_keywords

def test_check_images(mock_dataset):
    corrupt_files = check_images(str(mock_dataset), max_workers=4)
    print("\n损坏文件：", corrupt_files)
    assert any("corrupt.jpg" in p or "img_" in p for p in corrupt_files)  # 至少检测到一张损坏图片

def test_analyze_balance(mock_dataset):
    corrupt_files = check_images(str(mock_dataset), max_workers=4)
    train_path = mock_dataset / "train"
    class_counts, corrupt_counts = analyze_balance(str(train_path), corrupt_files)

    print("\n类别统计：", class_counts)
    print("\n损坏统计：", corrupt_counts)

    assert str(10000) in class_counts
    assert str(10001) in class_counts
    assert class_counts[str(10001)] == 0  # 空类别

