import pytest
from pathlib import Path
from PIL import Image
import shutil
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_validation import  check_images,is_image_corrupt

REPORT_FILE = Path("mock_dataset/check_images_report.md")
REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
REPORT_FILE.write_text("# check images 自动化测试报告\n", encoding="utf-8")

def create_good_image(path: Path):
    img = Image.new('RGB', (10, 10), color='red')
    img.save(path, format='JPEG')

def create_bad_image(path: Path):
    with open(path, "wb") as f:
        f.write(b"This is not a valid image file")

@pytest.fixture(scope="module")
def setup_test_images():
    test_dir = Path("mock_dataset/test_corrupt")

    #在每次测试运行前自动清理旧内容
    if test_dir.exists():
        shutil.rmtree(test_dir)
        print(f"\n已清理旧测试文件夹: {test_dir.resolve()}")

    test_dir.mkdir(parents=True, exist_ok=True)

    good_img = test_dir / "good.jpg"
    bad_img = test_dir / "bad.jpg"
    nested_dir = test_dir / "nested"
    nested_dir.mkdir()
    nested_good_img = nested_dir / "nested_good.jpg"

    create_good_image(good_img)
    create_bad_image(bad_img)
    create_good_image(nested_good_img)

    print(f"\n已创建测试文件:")
    # REPORT_FILE.write_text(f"已创建测试文件: \n", encoding="utf-8")
    # REPORT_FILE.write_text(f"- Good image: {good_img.resolve()}", encoding="utf-8")
    print(f"- Good image: {good_img.resolve()}")
    print(f"- Bad image: {bad_img.resolve()}")
    print(f"- Nested good image: {nested_good_img.resolve()}")


    yield test_dir

    # 不清理，保留供查看，直至下次运行时自动清理
    print(f"\n测试完成，已保留测试文件夹: {test_dir.resolve()}")

def write_report(title, found_dirs):
    with open(REPORT_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n## {title}\n")
        for keyword, path in found_dirs:
            f.write(f"- `{keyword}` : {path}\n")

    print(f"\n报告已写入: {REPORT_FILE.resolve()}")

def test_is_image_corrupt_good_and_bad(setup_test_images):
    test_dir = setup_test_images
    good_path = test_dir / "good.jpg"
    bad_path = test_dir / "bad.jpg"

    # 构建写入报告内容
    found_dirs = [
        ("正在测试 is_image_corrupt", ""),
        ("Good image path", str(good_path.resolve())),
        ("Bad image path", str(bad_path.resolve()))
    ]

    assert is_image_corrupt(good_path) is None, "正常图片应返回 None"

    result = is_image_corrupt(bad_path)
    # 统一路径比较
    assert os.path.normpath(str(result)) == os.path.normpath(str(bad_path)), "损坏图片应返回文件路径"

    found_dirs.append(("损坏图片检测结果", str(result.resolve() if hasattr(result, 'resolve') else result)))

    write_report("测试 is_image_corrupt", found_dirs)

def test_check_images_detect_corrupt(setup_test_images):
    test_dir = setup_test_images
    corrupt_files = check_images(str(test_dir), max_workers=4)

    corrupt_files_str = [os.path.normpath(str(Path(p).resolve())) for p in corrupt_files]

    found_dirs = [
        ("检测到的损坏文件列表", "\n".join(corrupt_files_str) if corrupt_files_str else "无")
    ]

    write_report("检测 check_images 检测到的损坏图片", found_dirs)

    assert os.path.normpath(str((test_dir / "bad.jpg").resolve())) in corrupt_files_str, "应检测到损坏文件"
    assert os.path.normpath(str((test_dir / "good.jpg").resolve())) not in corrupt_files_str, "不应误判正常文件"
    assert os.path.normpath(str((test_dir / "nested/nested_good.jpg").resolve())) not in corrupt_files_str, "不应误判嵌套正常文件"
