import os
import shutil

import pytest
import sys
from unittest import mock
from pathlib import Path

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_validation import find_valid_structure_dirs, check_images, analyze_balance

# 自动创建 mock_dataset 路径及报告文件
REPORT_FILE = Path("mock_dataset/find_valid_structure_report.md")
REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
# 每次测试前清空报告文件
REPORT_FILE.write_text("# find_valid_structure_dirs 自动化测试报告\n", encoding="utf-8")

def write_report(title, found_dirs):
    with open(REPORT_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n## {title}\n")
        for keyword, path in found_dirs:
            f.write(f"- `{keyword}` : {path}\n")

def test_only_train():
    test_dir = Path("mock_dataset/test1")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)
    (test_dir / "train").mkdir()

    found_dirs = find_valid_structure_dirs(str(test_dir))
    write_report("仅有 train 目录", found_dirs)

    assert any("train" in k and "缺失" not in p for k, p in found_dirs)
    assert any("val/validation/test" in k and "缺失" in p for k, p in found_dirs)

def test_only_val():
    test_dir = Path("mock_dataset/test2")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)
    (test_dir / "val").mkdir()

    found_dirs = find_valid_structure_dirs(str(test_dir))
    write_report("仅有 val 目录", found_dirs)

    assert any("train" in k and "缺失" in p for k, p in found_dirs)
    assert any("val/validation/test" in k and "缺失" not in p for k, p in found_dirs)

def test_all_exist():
    test_dir = Path("mock_dataset/test3")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)
    (test_dir / "train").mkdir()
    (test_dir / "validation").mkdir()
    (test_dir / "val").mkdir()
    (test_dir / "test").mkdir()

    found_dirs = find_valid_structure_dirs(str(test_dir))
    write_report("train, validation, val, test 均存在（测试优先选择）", found_dirs)

    assert any("train" in k and "缺失" not in p for k, p in found_dirs)
    assert any("val/validation/test" in k and "缺失" not in p for k, p in found_dirs)

def test_none_exist():
    test_dir = Path("mock_dataset/test4")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)

    found_dirs = find_valid_structure_dirs(str(test_dir))
    write_report("train, val/validation/test 均缺失", found_dirs)

    assert any("train" in k and "缺失" in p for k, p in found_dirs)
    assert any("val/validation/test" in k and "缺失" in p for k, p in found_dirs)

def test_case_sensitive():
    test_dir = Path("mock_dataset/test5")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)
    (test_dir / "Train").mkdir()
    (test_dir / "VALidation").mkdir()

    found_dirs = find_valid_structure_dirs(str(test_dir))
    write_report("区分大小写检测", found_dirs)

    assert any("train" in k and "缺失" not in p for k, p in found_dirs)
    assert any("val/validation/test" in k and "缺失" not in p for k, p in found_dirs)
