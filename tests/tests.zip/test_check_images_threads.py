import time
import pytest
from pathlib import Path
from PIL import Image
import shutil
import os
import sys
import re

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_validation import  check_images,is_image_corrupt

# 自动创建 mock_dataset 路径及报告文件
REPORT_FILE = Path("mock_dataset/check_images_thread_report.md")
REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
# 每次测试前清空报告文件
REPORT_FILE.write_text("# test_check_images_threads 自动化测试报告\n", encoding="utf-8")

def write_report(title: str, found_dirs):
    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)

    lines = [f"## {title}\n"]
    for keyword, path in found_dirs:
        lines.append(f"- {keyword}: {path}")
    lines.append("\n")

    with open(REPORT_FILE, "a", encoding="utf-8") as f:
        f.write("\n".join(lines))

def create_good_image(path: Path):
    img = Image.new('RGB', (10, 10), color='blue')
    img.save(path, format='JPEG')

@pytest.fixture(scope="module")
def setup_large_amount_images():
    test_dir = Path("mock_dataset/test_many_images")

    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir(parents=True, exist_ok=True)

    num_images = 500  # 可调大小
    for i in range(num_images):
        img_path = test_dir / f"img_{i:04}.jpg"
        create_good_image(img_path)

    # 写入报告记录创建情况
    found_dirs = [
        ("测试准备", f"已创建 {num_images} 张测试图片于 {test_dir.resolve()}")
    ]
    write_report("测试环境初始化", found_dirs)

    yield test_dir

    # 不删除，留作保留
    found_dirs = [
        ("测试保留", f"测试图片已保留于 {test_dir.resolve()}，可手动清理")
    ]
    write_report("测试完成环境保留", found_dirs)

@pytest.mark.parametrize("num_workers", [1, 4, 8])
def test_check_images_threads_performance(setup_large_amount_images, num_workers):
    test_dir = setup_large_amount_images

    start_time = time.perf_counter()
    corrupt_files = check_images(str(test_dir), max_workers=num_workers)
    elapsed = time.perf_counter() - start_time

    found_dirs = [
        (f"{num_workers}线程检测耗时", f"{elapsed:.4f}秒"),
        ("检测到损坏文件数量", str(len(corrupt_files))),
        ("测试路径", str(test_dir.resolve()))
    ]

    write_report(f"{num_workers}线程性能测试结果", found_dirs)

    assert len(corrupt_files) == 0, "不应检测到任何损坏文件"

def test_thread_speedup_analysis():
    """
    读取生成的 md 报告，对比不同线程耗时，并写入分析结果，无 print
    """
    report_path = REPORT_FILE
    if not report_path.exists():
        pytest.skip("未生成报告，跳过加速分析")

    times = {}
    with open(report_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines:
            match = re.search(r"(\d+)线程检测耗时:\s*([\d.]+)秒", line)
            if match:
                num_threads = int(match.group(1))
                elapsed_sec = float(match.group(2))
                times[num_threads] = elapsed_sec

    report_lines = [f"## 性能加速分析"]
    if 1 in times and 4 in times and 8 in times:
        t1, t4, t8 = times[1], times[4], times[8]
        report_lines.append(f"- 1线程耗时: {t1:.4f}秒")
        report_lines.append(f"- 4线程耗时: {t4:.4f}秒")
        report_lines.append(f"- 8线程耗时: {t8:.4f}秒")

        assert t4 <= t1 * 1.2, f"4线程加速不足: {t4:.4f}s vs {t1:.4f}s"
        assert t8 <= t1 * 1.2, f"8线程加速不足: {t8:.4f}s vs {t1:.4f}s"

        report_lines.append("- 线程并发加速符合预期")
    else:
        report_lines.append("- 未能提取完整的1/4/8线程测试耗时，跳过断言")

    with open(report_path, "a", encoding="utf-8") as f:
        f.write("\n".join(report_lines) + "\n")
